﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Bingo1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void button17_Click(object sender, EventArgs e) 
        {
            var rand = new Random();

            button1.Text = System.Convert.ToString(rand.Next(1,90));
            button2.Text = System.Convert.ToString(rand.Next(1, 90));
            button3.Text = System.Convert.ToString(rand.Next(1, 90));
            button4.Text = System.Convert.ToString(rand.Next(1, 90));
            button5.Text = System.Convert.ToString(rand.Next(1, 90));
            button6.Text = System.Convert.ToString(rand.Next(1, 90));
            button7.Text = System.Convert.ToString(rand.Next(1, 90));
            button8.Text = System.Convert.ToString(rand.Next(1, 90));
            button9.Text = System.Convert.ToString(rand.Next(1, 90));
            button10.Text = System.Convert.ToString(rand.Next(1, 90));
            button11.Text = System.Convert.ToString(rand.Next(1, 90));
            button12.Text = System.Convert.ToString(rand.Next(1, 90));
            button13.Text = System.Convert.ToString(rand.Next(1, 90));
            button14.Text = System.Convert.ToString(rand.Next(1, 90));
            button15.Text = System.Convert.ToString(rand.Next(1, 90));
            button16.Text = System.Convert.ToString(rand.Next(1, 90));

            button1.BackColor = Color.Blue;
            button2.BackColor = Color.Blue;
            button3.BackColor = Color.Blue;
            button4.BackColor = Color.Blue;
            button5.BackColor = Color.Blue;
            button6.BackColor = Color.Blue;
            button7.BackColor = Color.Blue;
            button8.BackColor = Color.Blue;
            button9.BackColor = Color.Blue;
            button10.BackColor = Color.Blue;
            button11.BackColor = Color.Blue;
            button12.BackColor = Color.Blue;
            button13.BackColor = Color.Blue;
            button14.BackColor = Color.Blue;
            button15.BackColor = Color.Blue;
            button16.BackColor = Color.Blue;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.Black;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button7.BackColor = Color.Black;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button6.BackColor = Color.Black;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button5.BackColor = Color.Black;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            button11.BackColor = Color.Black;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.BackColor = Color.Black;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button3.BackColor = Color.Black;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button4.BackColor = Color.Black;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            button12.BackColor = Color.Black;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            button13.BackColor = Color.Black;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            button14.BackColor = Color.Black;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            button15.BackColor = Color.Black;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            button16.BackColor = Color.Black;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button8.BackColor = Color.Black;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button9.BackColor = Color.Black;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            button10.BackColor = Color.Black;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            var rand1 = new Random();

            button19.Text = System.Convert.ToString(rand1.Next(1, 90));
        }
    }
}
