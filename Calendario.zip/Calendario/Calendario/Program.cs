﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calendario
{
    class Program
    {
        static void Main(string[] args)
        {
            //string MesingresoNombre;
            int diaIngreso;
            int añoIngreso;
            int MesIngreso=0;
            int Relativo;

            int diasalida=0;
            int Nombrediasalida=0;
            int añosalida=0;

            Fecha CalendarioHAAB = new Fecha();

            string[] mesesHAAB = { "pop", "no", "zip", "zotz", "tzec", "xul", "yoxkin", "mol", "chen", "yax", "zac", "ceh", "mac", "kankin", "muan", "pax", "koyab", "cumhu", "uayet" };

            CalendarioHAAB.HAAB = mesesHAAB;

            Fecha CalendarioSalida = new Fecha();



            string[] diastzilkin = { "imix", "ik", "akbal", "kan", "chiccha", "cimi", "manik", "lamat", "muluk", "ok", "chuen", "eb", "ben", "ix", "mem", "cib", "caban", "eznab", "canac", "ahau" };

            CalendarioSalida.Tzlkin = diastzilkin;


            Console.WriteLine("ingrese la fecha en HAAB");

            string fechaIngreso = Console.ReadLine();

            string[] fechaPartida = fechaIngreso.Split(' ');

            diaIngreso = int.Parse(fechaPartida[0]);
            añoIngreso = int.Parse(fechaPartida[2]);

            for(int i=0; i < mesesHAAB.Length; i++)
            {
                if (mesesHAAB[i] == fechaPartida[1])
                {
                    MesIngreso = i+1;
                }
            }

            if (MesIngreso == 19)
            {
                Relativo=añoIngreso * 365 + 360 + (diaIngreso + 1);
            }
            else
            {
                Relativo = añoIngreso * 365 + (MesIngreso - 1) * 20 + (diaIngreso + 1);
            }

            int x = 0;
            int num = 1;
            int dia = 1;

            while (x < Relativo)
            {
                
                if (num == 13)
                {
                    num = 0;

                    
                }
                if (dia == 20)
                {
                    dia = 0;
                }
                num++;
                dia++;
                
                diasalida = num-1;
                Nombrediasalida = dia-1;
                añosalida = Relativo / 260;

                x++;

            }

            Console.WriteLine(diasalida + " " + CalendarioSalida.Tzlkin[Nombrediasalida-1] + " " + añosalida);

           // Console.WriteLine(diaIngreso);
           // Console.WriteLine(MesIngreso);
           // Console.WriteLine(añoIngreso);


            Console.WriteLine(Relativo);

           // Console.WriteLine(CalendarioHAAB.HAAB[1]);
            //Console.WriteLine(CalendarioSalida.Tzlkin[1]);

            Console.ReadLine();
        }
    }
}
