﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Encriptado
{
    public class Encriptador
    {
        char[] alfabetoMinucsula = { 'a', 'b', 'c',  'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
        public char[] GenerarAbecedarios(char letraInicio) {
            int contadora = 0;
            int contadora2 = 0;
            char[] retorno = new char[alfabetoMinucsula.Length];
            //este ciclo retorna la  poscicion donde se encuentra la letra ingresada segun el alfabeto de minucsculas
            for (int i=0;i<alfabetoMinucsula.Length;i++) {
                if (letraInicio.Equals(alfabetoMinucsula[i])) {
                    break;
                }
                contadora2++;
            }
            //ciclo genera el abecedario tomando como palabra inicila la que  retorna el ciclo anterior 
            while (contadora < alfabetoMinucsula.Length) {
                if (contadora2 == 25 && contadora < 25)
                {
                    retorno[contadora] = alfabetoMinucsula[contadora2];
                    contadora2 = -1;
                }
                else {
                    retorno[contadora] = alfabetoMinucsula[contadora2];

                }
                contadora2++;
                contadora++;
            }
         return retorno;
        }
        public char[] Encriptar(char[] abecedario,char[] Aencriptado ,char [] cadena) {
            char[] PalabraEmcriptaa = new char[cadena.Length];
            int  contadora = 0;
            while (contadora<cadena.Length) {
                for (int i = 0; i < abecedario.Length; i++) {
                    if (abecedario[i].Equals(cadena[contadora])) {
                        PalabraEmcriptaa[contadora] = Aencriptado[i];
                    }
                }
                contadora++;

            }
            return PalabraEmcriptaa;
            
        }

       
    }
}
